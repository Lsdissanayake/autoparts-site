<?php

    //---------------------------[CAUTION]----------------------------------//
    //Stil in Prototype mode and data derived using GET Method
    //Security level is unstable

    //IDETIFIED SOLUTIONS: Turn to POST Method Curl PHP
    //----------------------------------------------------------------------// 

    session_start();

    $error = "";
    echo "session step";

    // if(!isset($_SESSION['username'])){
    //     header("location: ../login.html");
    //     exit();
    // }

    $user = $_GET['username'];
    $role = $_GET['role'];
    $mode = $_GET['mode'];
    $contact = $_GET['contact'];

    //Session variables
    $_SESSION['Username'] = $user;
    $_SESSION['Role'] = $role;
    $_SESSION['Mode'] = $mode;
    $_SESSION['Contact'] = $contact;

    // echo "Username is ".$_GET['contact'];

    header("Location:../index.php");




?>