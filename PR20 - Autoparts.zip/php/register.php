<?php

session_start();
	$msg = "";
	//datbase conection string 
	$db = new mysqli("localhost", "root", "", "lbs_db");
	//submission the registration
	if(isset($_POST['btn_register'])){
		//assigning values to php variables while preventing sql injection attacks
		$uname = $_POST['username'];
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$cpass = $_POST['cpass'];
		$pass = password_hash($_POST['pass'], PASSWORD_DEFAULT);
		$email = $_POST['email'];

		
		//confirming password = Confirm Password 
		if(password_verify($cpass, $pass)){
			//creating query string
			$sqlC = "INSERT INTO users(username, name, contact, password) VALUES('$uname', '$name', '$contact', '$pass')";
			//executing sql command through database connection
			if($db->query($sqlC))
				{
					?> <script type="text/javascript">
						alert("Registration Complete");
						window.location.href = "../index.php";
					</script><?php
					$msg ="Registration Complete";
				} else {
					$msg ="Registration Incomplete";
					?> <script type="text/javascript">
						alert("Registration Incomplete. Try Again!");
					</script> <?php

				}

		} else{
			$msg = "Your password dosent Match";
			?> <script type="text/javascript">
						alert("Password and Confirm password doesn't match. Try Again!");
						window.location.href = "../../signup.html";
					</script> <?php

		}
    }


?>