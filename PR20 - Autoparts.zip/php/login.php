<?php

session_start();
	$msg = "";
	//datbase conection string 
	// $db = new mysqli("localhost", "root", "", "inventory_db1");
	//submission the registration
    echo "Login";
	if(isset($_POST['btn_login'])){
		//assigning values to php variables while preventing sql injection attacks
		$pass = $_POST['password'];
		// $cpass = mysql_real_escape_string($_POST['cpassword']);
		$email = $_POST['username'];

		echo $email;
		//connecting db
        $con = mysqli_connect("localhost","root","");
        $db = mysqli_select_db($con, "lbs_db");

        //creating variable to query command
        $com = "SELECT * FROM users where username = '$email'";
        
        //execute command and assign it to a variable
        $sqlR = mysqli_query($con, $com) or die("Error has Occured...");

        //
        $sqlF = mysqli_fetch_assoc($sqlR);
        // echo $sqlF['password'];
        //verifying the values that entered with values in DB
        if($sqlF['username']==$email) //AND password_verify($pass, $sqlF['password'])
        {
            echo "login successful";
            $level = "Admin";
            $_SESSION['Username'] = $email;
            $_SESSION['Role'] = $level;
            // if(preg_match('/ADM*/', $usnam)){
            //     $_SESSION['level'] = 4;
            // } else if(preg_match('/GCA*/', $usnam)){
            //     $_SESSION['level'] = 3;
            // } else if(preg_match('/GCO*/', $usnam)){
            //     $_SESSION['level'] = 1;
            // } else $_SESSION['level'] = 1;
            
            
            ?><script type="text/javascript">
                //confirm redirection
                if(confirm("Login successful. Need to get to the Home Page ? "))
                {
                    //redirect home page
                    window.location.href = "../index.php";
                } else {
                    window.location.href="../blank.php";
                    
                    
                }


            </script> <?php
        } else {
            // echo "login failed"+$email+" ||"+$email;
            ?><script type="text/javascript">
                //Incorrect login message
                window.location.href="../page-login.php";
                alert("Username or Password Incorrect.");
            </script><?php
        }
    }


?>