<?php

echo 
'
                                    <!-- Left sidebar -->
                                    <div class="inbox-leftbar">
                                        <a class="btn btn-danger btn-block waves-effect waves-light" href="email-compose.php">Compose</a>

                                        <div class="mail-list mt-4">
                                            <a class="list-group-item border-0" href="email-inbox.php"><i class="mdi mdi-inbox font-18 align-middle mr-2"></i><b>Inbox</b></a>
                                            <a class="list-group-item border-0" href="#"><i class="mdi mdi-file-document-box font-18 align-middle mr-2"></i>Draft</a>
                                            <a class="list-group-item border-0" href="email-sent.php"><i class="mdi mdi-send font-18 align-middle mr-2"></i>Sent Mail</a>
                                            <a class="list-group-item border-0" href="#"><i class="mdi mdi-delete font-18 align-middle mr-2"></i>Trash</a>
                                        </div>

                                        <h6 class="mt-5 m-b-15">Labels</h6>

                                        <div class="list-group b-0 mail-list">
                                            <a class="list-group-item border-0" href="#"><span class="fa fa-circle text-info mr-2"></span>Sample Label</a>
                                            
                                        </div>

                                    </div>
                                    <!-- End Left sidebar -->

'

?>