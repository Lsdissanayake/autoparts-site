<?php

echo 
'
<footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://google.com">SampleXXX</a></footer>
'

?>